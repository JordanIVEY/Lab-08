public class PrettyHeader {
    public static void printHeader(String msg) {
        SafeInput.prettyHeader(msg);
    }
}
